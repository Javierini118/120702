﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5_JavierRuano_1207022
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Por favor ingrese su priemra cantidad de quetzales");
            double cantidadDeQuetzales1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Por favor ingrese su  segunda cantidad de quetzales");
            double cantidadDeQuetzales2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Por favor ingrese su tercera   cantidad de quetzales");
            double cantidadDeQuetzales3 = Convert.ToDouble(Console.ReadLine());


            double cantidadDeDolls = 7.88;

            double cantidadFinal1 = cantidadDeQuetzales1 / cantidadDeDolls;
            double cantidadFinal2 = cantidadDeQuetzales2 / cantidadDeDolls;
            double cantidadFinal3 = cantidadDeQuetzales3 / cantidadDeDolls;

            Console.WriteLine("***************************************************************************************************************");
            Console.WriteLine("Su primera cantidad es de    " + cantidadDeQuetzales1 + " y su cantidad de dollares es de " + cantidadFinal1);
            Console.WriteLine("Su sergunda cantidad es de   " + cantidadDeQuetzales2 + " y su cantidad de dollares es de " + cantidadFinal2);
            Console.WriteLine("Su tercera cantidad es de    " + cantidadDeQuetzales3 + " y su cantidad de dollares es de " + cantidadFinal3);
            Console.WriteLine("**************************************************************************************************************");
            Console.ReadKey();
            Console.Clear();


            if (cantidadFinal1 > cantidadFinal2 && cantidadFinal1 > cantidadFinal3)
            {
                Console.WriteLine("El primer numero es mayor");
            }
            else if (cantidadFinal2 > cantidadFinal1 && cantidadFinal2 > cantidadFinal3)
            {
                Console.WriteLine("El segundo numero es mayor");
            }
            else if (cantidadFinal3 > cantidadDeQuetzales1 && cantidadFinal3 > cantidadFinal2)
            {
                Console.WriteLine("El tercer numero es mayor");
            }






        }
    }
}
