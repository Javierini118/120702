﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_JavierRuano_1207022
{
    internal class Program
    {
        static void Main(string[] args)
        { // inicio

            
            Console.WriteLine("Bienvenido al menú de laboratorio ¿Qué desea hacer? ");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("1) Ingrese un numero y verificar si es negativo");
            Console.WriteLine("2 Ingrese un numero y verifique el dia de la semana");
            Console.WriteLine("3) salir");
            Console.WriteLine("----------------------------------------------------"); 
            int ElegirNúmero = Convert.ToInt32(Console.ReadLine());
            switch (ElegirNúmero)
            {
                case 1:
                    Console.Clear(); 

                    Console.WriteLine("Por favor ingrese un numero ");
                    int numero = Convert.ToInt32(Console.ReadLine());


                    if (numero < 0)
                    {
                        Console.WriteLine("su numero es negativo ");

                    }


                    if (numero == 0)
                    {
                        Console.WriteLine("su numero es cero ");

                    }

                    if (numero > 0)
                    {
                        Console.WriteLine("su numero es positivo ");


                    }

                    Console.ReadKey();
                    break;


                    case 2:
                    Console.Clear(); 

                    Console.WriteLine("Ingrese un numero");
                    int NumeroDia = Convert.ToInt32(Console.ReadLine());

                    if (NumeroDia == 1)
                    {
                        Console.WriteLine("Su dia es lunes");
                    }
                    else if (NumeroDia == 2)
                    {
                        Console.WriteLine("Su dia es martes");
                    }
                    else if (NumeroDia == 3)
                    {
                        Console.WriteLine("Su dia es miercoles");
                    }
                    else if (NumeroDia == 4)
                    {
                        Console.WriteLine("Su dia es Jueves");
                    }
                    else if (NumeroDia == 5)
                    {
                        Console.WriteLine("Su dia es viernes");
                    }
                    else if (NumeroDia == 6)
                    {
                        Console.WriteLine("Su dia es sabado");
                    }
                    else if (NumeroDia == 7)
                    {
                        Console.WriteLine("Su dia es Domingo");
                    }
                    else
                    {
                        Console.WriteLine("lo sentimos no es un dia");
                    }

                    Console.ReadKey(); 

                    break;

                case 3: 

                    break;

            }

        }// fin 
    }
}
